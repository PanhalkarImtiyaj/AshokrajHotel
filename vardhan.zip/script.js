// Vardhan Educational Consultant - Landing Page JavaScript

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    
    // Initialize all functionality
    initializeSlider();
    initializeSmoothScrolling();
    initializeAnimations();
    updateCurrentYear();
    
    console.log('Vardhan Educational Consultant - Landing Page Loaded Successfully');
});

// ===== SLIDER FUNCTIONALITY =====
function initializeSlider() {
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.dot');
    let currentSlide = 0;
    const totalSlides = slides.length;
    let sliderInterval;
    
    if (slides.length === 0 || dots.length === 0) {
        console.warn('Slider elements not found');
        return;
    }
    
    // Initialize all slides as hidden
    slides.forEach((slide, index) => {
        slide.style.opacity = '0';
        slide.style.visibility = 'hidden';
        slide.style.zIndex = '1';
        slide.classList.remove('active');
    });
    
    // Show initial slide
    showSlide(currentSlide);
    
    // Start auto-advance - images will change automatically
    startAutoSlide();
    
    // Add click event listeners to dots
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            currentSlide = index;
            showSlide(currentSlide);
            resetAutoSlide(); // Reset timer when user clicks dots
        });
    });
    
    function showSlide(index) {
        // Ensure index is valid
        if (index < 0 || index >= totalSlides) {
            index = 0;
            currentSlide = 0;
        }
        
        // Hide all slides with proper transition
        slides.forEach((slide, i) => {
            slide.classList.remove('active');
            slide.style.opacity = '0';
            slide.style.visibility = 'hidden';
            slide.style.zIndex = '1';
        });
        
        // Remove active class from all dots
        dots.forEach(dot => {
            dot.classList.remove('active');
        });
        
        // Show current slide with transition
        if (slides[index] && dots[index]) {
            setTimeout(() => {
                slides[index].style.visibility = 'visible';
                slides[index].style.zIndex = '2';
                slides[index].style.opacity = '1';
                slides[index].classList.add('active');
            }, 50);
            
            dots[index].classList.add('active');
        }
        
        console.log(`Showing slide ${index + 1} of ${totalSlides}`);
    }
    
    function startAutoSlide() {
        sliderInterval = setInterval(() => {
            currentSlide = (currentSlide + 1) % totalSlides;
            showSlide(currentSlide);
        }, 5000);
    }
    
    function resetAutoSlide() {
        clearInterval(sliderInterval);
        startAutoSlide();
    }
    
    // Touch/swipe functionality for mobile
    let startX = 0;
    let endX = 0;
    let startY = 0;
    let endY = 0;
    
    const sliderContainer = document.querySelector('.slider-container');
    if (sliderContainer) {
        sliderContainer.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
            startY = e.touches[0].clientY;
            // Pause auto-slide during touch interaction
            clearInterval(sliderInterval);
        }, { passive: true });
        
        sliderContainer.addEventListener('touchend', (e) => {
            endX = e.changedTouches[0].clientX;
            endY = e.changedTouches[0].clientY;
            handleSwipe();
            // Resume auto-slide after touch interaction
            setTimeout(() => {
                startAutoSlide();
            }, 1000);
        }, { passive: true });
        
        function handleSwipe() {
            const swipeThreshold = 75; // Increased threshold for better mobile UX
            const diffX = startX - endX;
            const diffY = startY - endY;
            
            // Only handle horizontal swipes (ignore vertical scrolling)
            // Require horizontal movement to be significantly more than vertical
            if (Math.abs(diffX) > Math.abs(diffY) * 1.5 && Math.abs(diffX) > swipeThreshold) {
                // Prevent default scrolling behavior
                if (Math.abs(diffX) > swipeThreshold) {
                    if (diffX > 0) {
                        // Swipe left - next slide
                        currentSlide = (currentSlide + 1) % totalSlides;
                    } else {
                        // Swipe right - previous slide
                        currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
                    }
                    showSlide(currentSlide);
                    resetAutoSlide(); // Reset timer after swipe
                }
            }
        }
        
        // Pause auto-slide when user is interacting
        sliderContainer.addEventListener('mouseenter', () => {
            clearInterval(sliderInterval);
        });
        
        sliderContainer.addEventListener('mouseleave', () => {
            startAutoSlide();
        });
    }
    
    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
            showSlide(currentSlide);
            resetAutoSlide(); // Reset timer after keyboard navigation
        } else if (e.key === 'ArrowRight') {
            currentSlide = (currentSlide + 1) % totalSlides;
            showSlide(currentSlide);
            resetAutoSlide(); // Reset timer after keyboard navigation
        }
    });
    
    // Pause slider when page is not visible
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            clearInterval(sliderInterval);
        } else {
            startAutoSlide();
        }
    });
}

// ===== SMOOTH SCROLLING =====
function initializeSmoothScrolling() {
    // Add smooth scrolling to all anchor links
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    
    anchorLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            // Skip if it's just "#" or empty
            if (href === '#' || href === '') {
                return;
            }
            
            const targetElement = document.querySelector(href);
            if (targetElement) {
                e.preventDefault();
                
                // Calculate offset for fixed header
                const headerHeight = document.querySelector('.header')?.offsetHeight || 0;
                const targetPosition = targetElement.offsetTop - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// ===== ANIMATIONS =====
function initializeAnimations() {
    // Intersection Observer for scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
                
                // Animate stats numbers
                if (entry.target.classList.contains('stat-card')) {
                    animateStatNumbers(entry.target);
                }
                
                // Animate progress bars
                if (entry.target.classList.contains('progress-item')) {
                    animateProgressBar(entry.target);
                }
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animateElements = document.querySelectorAll('.stat-card, .feature-card, .service-card, .progress-item');
    animateElements.forEach(el => {
        observer.observe(el);
    });
}

// Animate stat numbers
function animateStatNumbers(statCard) {
    const numberElement = statCard.querySelector('.stat-content h3, .stat-number');
    if (!numberElement) return;
    
    const finalNumber = numberElement.textContent.match(/\d+/);
    if (!finalNumber) return;
    
    const target = parseInt(finalNumber[0]);
    const suffix = numberElement.textContent.replace(/\d+/, '');
    let current = 0;
    const increment = target / 50;
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            current = target;
            clearInterval(timer);
        }
        numberElement.textContent = Math.floor(current) + suffix;
    }, 30);
}

// Animate progress bars
function animateProgressBar(progressItem) {
    const progressFill = progressItem.querySelector('.progress-fill');
    if (!progressFill) return;
    
    const targetWidth = progressFill.style.width;
    progressFill.style.width = '0%';
    
    setTimeout(() => {
        progressFill.style.width = targetWidth;
    }, 100);
}

// ===== UTILITY FUNCTIONS =====

// Update current year in footer
function updateCurrentYear() {
    const yearElement = document.getElementById('currentYear');
    if (yearElement) {
        yearElement.textContent = new Date().getFullYear();
    }
}

// Add loading states for external links
function addLoadingStates() {
    const externalLinks = document.querySelectorAll('a[href^="https://wa.me"], a[href^="mailto:"]');
    
    externalLinks.forEach(link => {
        link.addEventListener('click', function() {
            // Add a brief loading state
            const originalText = this.textContent;
            this.style.opacity = '0.7';
            this.style.pointerEvents = 'none';
            
            setTimeout(() => {
                this.style.opacity = '1';
                this.style.pointerEvents = 'auto';
            }, 1000);
        });
    });
}

// Handle form submissions (if any forms are added later)
function handleFormSubmissions() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Add your form handling logic here
            console.log('Form submitted:', new FormData(this));
            
            // Show success message
            showNotification('Thank you for your message! We will get back to you soon.', 'success');
        });
    });
}

// Show notifications
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Add styles
    Object.assign(notification.style, {
        position: 'fixed',
        top: '20px',
        right: '20px',
        padding: '1rem 1.5rem',
        borderRadius: '8px',
        color: 'white',
        fontWeight: '500',
        zIndex: '9999',
        transform: 'translateX(100%)',
        transition: 'transform 0.3s ease',
        backgroundColor: type === 'success' ? '#00b894' : type === 'error' ? '#e74c3c' : '#3498db'
    });
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 5000);
}

// Lazy loading for images
function initializeLazyLoading() {
    const images = document.querySelectorAll('img[data-src]');
    
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.removeAttribute('data-src');
                img.classList.add('loaded');
                imageObserver.unobserve(img);
            }
        });
    }, {
        rootMargin: '50px 0px',
        threshold: 0.1
    });
    
    images.forEach(img => {
        img.classList.add('lazy');
        imageObserver.observe(img);
    });
}

// Preload slider images for better performance
function preloadSliderImages() {
    const sliderImages = document.querySelectorAll('.slide-image img');
    
    sliderImages.forEach((img, index) => {
        if (index === 0) {
            // First image should load immediately
            return;
        }
        
        // Preload other images
        const preloadImg = new Image();
        preloadImg.src = img.src;
        preloadImg.onload = () => {
            console.log(`Preloaded slider image ${index + 1}`);
        };
    });
}

// Performance optimization
function optimizePerformance() {
    // Preload critical resources
    const criticalImages = [
        'images/Vardhan-Educational-Consultancy-scaled.jpg',
        'images/Vardhan Educational Consultant.png'
    ];
    
    criticalImages.forEach(src => {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.as = 'image';
        link.href = src;
        document.head.appendChild(link);
    });
}

// Initialize additional features when page loads
window.addEventListener('load', function() {
    addLoadingStates();
    initializeLazyLoading();
    preloadSliderImages();
    optimizePerformance();
    
    // Fix slider if images are not loading properly
    setTimeout(() => {
        const slides = document.querySelectorAll('.slide');
        if (slides.length > 0) {
            console.log('Slider initialized with', slides.length, 'slides');
            // Force show first slide if none are visible
            const activeSlide = document.querySelector('.slide.active');
            if (!activeSlide) {
                slides[0].classList.add('active');
                slides[0].style.opacity = '1';
                slides[0].style.visibility = 'visible';
                slides[0].style.zIndex = '2';
                
                const firstDot = document.querySelector('.dot');
                if (firstDot) {
                    firstDot.classList.add('active');
                }
            }
        }
    }, 1000);
});

// Handle resize events
window.addEventListener('resize', function() {
    // Recalculate any size-dependent elements
    debounce(() => {
        console.log('Window resized, recalculating layouts...');
    }, 250)();
});

// Debounce utility function
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Error handling
window.addEventListener('error', function(e) {
    console.error('JavaScript Error:', e.error);
});

// Service Worker registration (for future PWA features)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        // Uncomment when you have a service worker
        // navigator.serviceWorker.register('/sw.js')
        //     .then(registration => console.log('SW registered'))
        //     .catch(error => console.log('SW registration failed'));
    });
}
